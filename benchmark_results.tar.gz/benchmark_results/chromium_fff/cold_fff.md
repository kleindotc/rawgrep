| Command | Mean [s] | Min [s] | Max [s] | Relative |
|:---|---:|---:|---:|---:|
| `fff (cache built once)` | 5.190 ± 0.228 | 5.044 | 5.783 | 1.88 ± 0.09 |
| `rawgrep` | 2.757 ± 0.042 | 2.722 | 2.812 | 1.00 |
