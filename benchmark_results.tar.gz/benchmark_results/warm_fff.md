| Command | Mean [ms] | Min [ms] | Max [ms] | Relative |
|:---|---:|---:|---:|---:|
| `fff (cache built once)` | 624.2 ± 13.4 | 598.8 | 651.7 | 4.80 ± 0.19 |
| `rawgrep` | 130.0 ± 4.4 | 119.3 | 143.1 | 1.00 |
