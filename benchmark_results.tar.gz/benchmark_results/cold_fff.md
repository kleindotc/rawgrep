| Command | Mean [s] | Min [s] | Max [s] | Relative |
|:---|---:|---:|---:|---:|
| `fff (cache built once)` | 5.107 ± 0.017 | 5.087 | 5.143 | 1.89 ± 0.02 |
| `rawgrep` | 2.697 ± 0.029 | 2.667 | 2.755 | 1.00 |
