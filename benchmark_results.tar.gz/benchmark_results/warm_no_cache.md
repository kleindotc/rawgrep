| Command | Mean [ms] | Min [ms] | Max [ms] | Relative |
|:---|---:|---:|---:|---:|
| `rawgrep (no cache)` | 314.9 ± 5.2 | 303.7 | 325.5 | 1.00 |
| `ripgrep` | 367.5 ± 6.1 | 357.4 | 384.9 | 1.17 ± 0.03 |
